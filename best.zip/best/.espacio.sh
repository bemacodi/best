#!/bin/bash

df -h | awk 'NR==4 {print $3}'

